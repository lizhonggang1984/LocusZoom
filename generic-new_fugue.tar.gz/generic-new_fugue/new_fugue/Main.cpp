////////////////////////////////////////////////////////////////////// 
// new_fugue/Main.cpp 
// (c) 2000-2010 Goncalo Abecasis
// 
// This file is distributed as part of the Goncalo source code package   
// and may not be redistributed in any form, without prior written    
// permission from the author. Permission is granted for you to       
// modify this file for your own personal use, but modified versions  
// must retain this copyright notice and must not be distributed.     
// 
// Permission is granted for you to use this file to compile Goncalo.    
// 
// All computer programs have bugs. Use this file at your own risk.   
// 
// Tuesday May 25, 2010
// 
 

#include "HaploSet.h"
#include "Parameters.h"
#include "Error.h"
#include "Random.h"
#include "Likelihood.h"
#include "SparseLikelihood.h"
#include "HaploFamily.h"
#include "ClusterInfo.h"


#include <math.h>

void ShowHeader();
void ReadParameters(int argc, char ** argv);
void LoadData();
void BreakFamilies();
void EstimateFrequencies();
void EstimatePairwiseLD();
void EstimateHaplotypes();
void HaplotypeFamilies(ClusterInfo & info);
void MaximizeLikelihood(ClusterInfo & info, bool print = false);
void ApproximateMaximizeLikelihood(ClusterInfo & info, bool print = false);

// Pedigree file contents
Pedigree ped;

// Input haplotype data
HaplotypeSets * sets;

// Name for input file
String datfile("merlin.dat");
String pedfile("merlin.ped");
String mapfile("merlin.map");
String prefix("fugue");

// Request approximate solution
int approximate = false;

// Maximum complexity for haplotype sets in analysis
int maxBits = 16;

// Number of restarts using random haplotype frequencies
int restarts = 10;

// Print additional information for incremental builds
bool additional = false;

// Convergence threshold
double tol = 1e-6;

// Display threshold
double minfreq = 0.0001;

// Smooth haplotype frequencies to favor similar haplotypes
// double pseudoMutation = 0.0;

// Divide And Conquer Approximation
bool useApproximation = false;

// Sample a proportion of pairwise LD coefficients
double sample = 0.0;

// Calculation workhorses
Likelihood likelihood;
SparseLikelihood sparseLikelihood;

// Minor allele frequencies
Vector MAF;
double maf = 0.0;

// Analysis options
bool estimateFrequencies = false;
bool estimatePairwise = false;
bool estimateHaplotypes = false;

// This variable is used for extracting a slice of pairwise coefficients
String pairWith;

// This option is used for generating gazillions of little files
bool tabulateBySnp = false;

// Options for haplotype frequency estimation
bool smoothing = false, fineSmoothing = false;

// Options for file with pairwise LD coefficients
bool saveIds = false;
bool saveLabels = false;
bool savePositions = true;
bool saveCoupling = false;
double deltaThreshold = _NAN_;

// Distance between markers in pairwise analyses
int maxDistance = 1000000;

// Reduce screen clutter
bool quiet = false;

int main(int argc, char ** argv)
   {
   ShowHeader();

   ReadParameters(argc, argv);
   
   LoadData();
   BreakFamilies();

   if (estimateFrequencies || maf > 0.0)
      EstimateFrequencies();

   if (estimatePairwise)
      EstimatePairwiseLD();

   if (estimateHaplotypes)
      EstimateHaplotypes();

   return 0;
   }

void ShowHeader()
   {
   printf("FUGUE - Frequency Using Graphs\n"
          "(c) 2001-2005 Goncalo Abecasis\n");
   }

BEGIN_LONG_PARAMETERS(longParameters)
   LONG_PARAMETER_GROUP("Performace")
      LONG_PARAMETER("approximation", &approximate)
      LONG_INTPARAMETER("haploBits", &maxBits)
   LONG_PARAMETER_GROUP("Frequencies")
      LONG_PARAMETER("alleles", &estimateFrequencies)
      LONG_PARAMETER("haplotype", &estimateHaplotypes)
   LONG_PARAMETER_GROUP("Pairwise")
      LONG_PARAMETER("diseq", &estimatePairwise)
      LONG_DOUBLEPARAMETER("maf", &maf)
      LONG_INTPARAMETER("window", &maxDistance)
      LONG_DOUBLEPARAMETER("sample", &sample)
      LONG_STRINGPARAMETER("pairWith", &pairWith)
      LONG_PARAMETER("tabulateBySnp", &tabulateBySnp)
   LONG_PARAMETER_GROUP("LD Output")
      LONG_PARAMETER("ids", &saveIds)
      LONG_PARAMETER("names", &saveLabels)
      LONG_PARAMETER("positions", &savePositions)
      LONG_PARAMETER("coupling", &saveCoupling)
      LONG_DOUBLEPARAMETER("minrsq", &deltaThreshold)
   LONG_PARAMETER_GROUP("Haplotypes")
//      LONG_DOUBLEPARAMETER("pseudoMutation", &pseudoMutation)
      LONG_PARAMETER("smoothing", &smoothing)
      LONG_PARAMETER("fineSmoothing", &fineSmoothing)
   LONG_PARAMETER_GROUP("Screen Output")
      LONG_PARAMETER("quiet", &quiet)
   BEGIN_LEGACY_PARAMETERS()
      LONG_PARAMETER("frequencies", &estimateHaplotypes)
      LONG_PARAMETER("estimate", &estimateFrequencies)
END_LONG_PARAMETERS()

void ReadParameters(int argc, char ** argv)
   {
   ParameterList pl;
   pl.Add(new StringParameter('d', "Data File", datfile));
   pl.Add(new StringParameter('p', "Pedigree File", pedfile));
   pl.Add(new StringParameter('m', "Map File", mapfile));
   pl.Add(new StringParameter('o', "Output File Prefix", prefix));
   pl.Add(new LongParameters("Additional Options", longParameters));
   pl.Read(argc, argv);
   pl.Status();
   }

void LoadData()
   {
   ped.Prepare(datfile);
   ped.Load(pedfile);

   if (estimatePairwise)
      ped.LoadBasepairMap(mapfile);

   ped.Trim();
   ped.EstimateFrequencies(FREQ_EQUAL, true);
   ped.LumpAlleles(0.0);
   }

void HaplotypeFamilies(ClusterInfo & info)
   {
   String       key;
   StringHash   lookup;
   FamilyHaplos engine;

   engine.markers = info.markerIds;

   sets->AllocateAlleleLabels(info.markers);
   for (int m = 0; m < info.markers; m++)
      sets->SetAlleleLabels(m, Pedigree::GetMarkerInfo(info.markerIds[m])->alleleLabels);

   for (int f = 0; f < ped.familyCount; f++)
      if (engine.Haplotype(ped, *(ped.families[f])))
         if (ped.families[f]->count > 6)
            sets->LoadFromMemory(&engine, info.markers);
         else
            {
            engine.RetrieveGenotypes(key, *ped.families[f]);
            int index = lookup.Find(key);

            if (index == -1)
               lookup.Add(key, sets->LoadFromMemory(&engine, info.markers));
            else
               ((HaplotypeSet *) lookup.Object(index))->copies++;
            }
   }

void MaximizeLikelihood(ClusterInfo & info, bool print)
   {
   sets = new HaplotypeSets;

   info.UpdateAlleleCounts();

   HaplotypeFamilies(info);

   sets->Filter(info.alleleCounts, maxBits);

   likelihood.tol = tol;
   likelihood.Initialize(info.alleleCounts);
   likelihood.EM(sets);

   if (print) likelihood.Print(0.001, sets);

   delete sets;
   }

void ApproximateMaximizeLikelihood(ClusterInfo & info, bool print)
   {
   sets = new HaplotypeSets;

   info.UpdateAlleleCounts();

   HaplotypeFamilies(info);

   sparseLikelihood.tol = tol;
   sparseLikelihood.Initialize(info.alleleCounts);
   sparseLikelihood.EM(sets);

   if (print) sparseLikelihood.Print(0.001, sets);

   delete sets;
   }

void EstimatePairwiseLD()
   {
   ClusterInfo info(2);

   FILE * ld = fopen(prefix + ".xt", "wt");
   FILE * log = NULL;
   int loglen = 0;

   if (saveIds) fprintf(ld, "MARKER1 MARKER2 ");
   if (saveLabels) fprintf(ld, "LABEL1 LABEL2 ");
   if (savePositions) fprintf(ld, "CHR MIDPOINT DISTANCE ");
   fprintf(ld, "DPRIME DELTASQ");
   if (saveCoupling) fprintf(ld, " COUPLING");
   fprintf(ld, "\n");

   IntArray sortedMarkers;
   Pedigree::GetOrderedMarkers(sortedMarkers);

   int pairWithId = pairWith.IsEmpty() ? -3 : ped.LookupMarker(pairWith);

   FILE ** miniFiles = tabulateBySnp ? new FILE * [ped.markerCount] : NULL;

   if (miniFiles != NULL)
      for (int i = 0; i < ped.markerCount; i++)
         miniFiles[i] = NULL;

   String outputBuffer;
   for (int i = 0, count = sortedMarkers.Length(); i < count; i++)
      {
      info.markerIds[0] = sortedMarkers[i];

      if (maf > 0.0 && (MAF[info.markerIds[0]] * 1.000001 < maf ||
                        MAF[info.markerIds[0]] == _NAN_))
         continue;

      MarkerInfo * info1 = Pedigree::GetMarkerInfo(info.markerIds[0]);

      if (!quiet)
         {
         printf("Pairwise LD %d/%d\r", info.markerIds[0], ped.markerCount);
         fflush(stdout);
         }

      for (int j = i + 1; j < count; j++)
         if (sample == 0.0 || globalRandom.Next() < sample)
            {
            info.markerIds[1] = sortedMarkers[j];

            if (maf > 0.0 && (MAF[info.markerIds[1]] * 1.000001 < maf ||
                              MAF[info.markerIds[1]] == _NAN_))
               continue;

            MarkerInfo * info2 = Pedigree::GetMarkerInfo(info.markerIds[1]);

            if (info1->chromosome != info2->chromosome ||
                info2->position - info1->position > maxDistance)
                break;

            if (pairWithId != -3 && pairWithId != info.markerIds[0] &&
                                   pairWithId != info.markerIds[1])
                continue;

            MaximizeLikelihood(info);

            double dprime, deltasq;
            int coupling;

            if (likelihood.PairwiseLD(dprime, deltasq, coupling))
               {
               if ((deltaThreshold == _NAN_) || (deltasq >= deltaThreshold))
                  {
                  if (miniFiles != NULL)
                     {
                     if (miniFiles[i] == NULL) miniFiles[i] = fopen((const char *) (info1->name + ".xt"), "wt");
                     if (miniFiles[j] == NULL) miniFiles[j] = fopen((const char *) (info2->name + ".xt"), "wt");
                     }

                  outputBuffer.Clear();

                  if (saveIds)
                     outputBuffer.catprintf("%d %d ", info.markerIds[0] + 1, info.markerIds[1] + 1);

                  if (saveLabels)
                     outputBuffer.catprintf("%s %s ",
                             (const char *) info1->name, (const char *) info2->name);

                  if (savePositions)
                     outputBuffer.catprintf("%d %.0f %.0f ",
                          info1->chromosome,
                          (info1->position + info2->position) * .5,
                          info2->position - info1->position);

                  outputBuffer.catprintf("%.5f %.5f", dprime, deltasq);

                  if (saveCoupling)
                     if (coupling == PAIRWISE_EQUILIBRIUM)
                        outputBuffer.catprintf(" *,*\n");
                     else
                        outputBuffer.catprintf(" %s,%s\n",
                              (const char *) info1->GetAlleleLabel(1),
                              (const char *) info2->GetAlleleLabel(
                                           coupling == PAIRWISE_COUPLING ? 1 : 2));
                  else
                     outputBuffer.catprintf("\n");

                  fprintf(ld, "%s", (const char *) outputBuffer);
                  if (miniFiles != NULL && miniFiles[j] != NULL) fprintf(miniFiles[j], "%s", (const char *) outputBuffer);
                  if (miniFiles != NULL && miniFiles[i] != NULL) fprintf(miniFiles[i], "%s", (const char *) outputBuffer);
                  }
               }
            else
               {
               if (log == NULL)
                  log = fopen(prefix + ".xt.log", "wt");

               if (loglen++ == 0)
                  printf("Problems estimating pairwise LD, see %s.xt.log for details\n\n",
                         (const char *) prefix);

               if (log != NULL)
                  if (loglen == 1000)
                     fprintf(log, "Too many problems, stopped logging\n");
                  else if (loglen < 1000)
                     fprintf(log, "Skipped markers %s and %s, because %s\n",
                        (const char *) Pedigree::markerNames[info.markerIds[0]],
                        (const char *) Pedigree::markerNames[info.markerIds[1]],
                        likelihood.failText);
               }
            }

      if (miniFiles != NULL && miniFiles[i] != NULL)
         {
         fclose(miniFiles[i]);
         miniFiles[i] = NULL;
         }
      }

   printf("Pairwise LD -- Done!      \n", info.markerIds[0], ped.markerCount);

   if (log != NULL) fclose(log);
   fclose(ld);
   }

void EstimateFrequencies()
   {
   ClusterInfo info(1);
   FILE * file = fopen(prefix + ".freq", "wt");

   MAF.Dimension(ped.markerCount);
   for (info.markerIds[0] = 0; info.markerIds[0] < ped.markerCount; info.markerIds[0]++)
      {
      if (!quiet)
         {
         printf("Allele frequencies %d/%d\r", info.markerIds[0], ped.markerCount);
         fflush(stdout);
         }

      MarkerInfo * info1 = Pedigree::GetMarkerInfo(info.markerIds[0]);

      MaximizeLikelihood(info);

      Vector & freqs = likelihood.best_frequencies;

      if (info1->freq.Length() > freqs.Length() + 1)
         {
         printf("Allele frequency estimation failed for marker %s\n",
                (const char *) ped.markerNames[info.markerIds[0]]);
         MAF[info.markerIds[0]] = _NAN_;
         continue;
         }

      fprintf(file, "M %s\n", (const char *) ped.markerNames[info.markerIds[0]]);
      for (int i = 1; i < info1->freq.Length(); i++)
         fprintf(file, "A %3s %.5f\n", (const char *) info1->GetAlleleLabel(i), freqs[i - 1]);

      double maf = 1.0;

      if (freqs.Length() > 1)
         for (int i = 0; i < freqs.Length(); i++)
            if (freqs[i] > 0.0 && freqs[i] < maf)
               maf = freqs[i];

      MAF[info.markerIds[0]] = fabs(maf - 1.0) < 1e-6 ? 0.0 : maf;
      }

   fclose(file);

   file = fopen(prefix + ".maf", "wt");
   for (int i = 0; i < ped.markerCount; i++)
      if (MAF[i] != _NAN_)
         fprintf(file, "%15s %.5f\n", (const char *) ped.markerNames[i], MAF[i]);
   fclose(file);

   printf("Allele frequencies -- Done!      \n", info.markerIds[0], ped.markerCount);
   }

void EstimateHaplotypes()
   {
   ClusterInfo info(ped.markerCount);
   info.markerIds.SetSequence(0, 1);

   if (!approximate)
      {
      likelihood.gradual_smoothing = fineSmoothing;
      likelihood.two_pass_smoothing = smoothing;
      likelihood.CheckSmoothing();

      MaximizeLikelihood(info, true);
      }
   else
      {
      ApproximateMaximizeLikelihood(info, true);
      }
   }

// This function breaks families into unique groups (if necessary)
void BreakFamilies()
   {
   IntArray groups;
   IntArray key;

   for (int f = 0; f < ped.familyCount; f++)
      if ( ped.families[f]->ConnectedGroups(&groups) != 1 )
         {
         key.Dimension(groups.Max());

         for (int i = 0, j = 1; i < key.Length(); j++)
            if (ped.FindFamily(ped.families[f]->famid + "$" + j) == NULL)
               key[i++] = j;

         for (int i = ped.families[f]->first; i <= ped.families[f]->last; i++)
            {
            ped[i].famid += "$";
            ped[i].famid += key[groups[ped[i].traverse] - 1];
            }
         }

   if (key.Length())
      ped.Sort();
   }


 
