#ifndef __VERSION_INFO_H__
#define __VERSION_INFO_H__


#ifndef VERSION 
#define VERSION "2010-05-25"
#endif


#endif


